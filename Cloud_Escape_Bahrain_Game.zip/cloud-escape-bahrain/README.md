# Cloud Escape – Cloud in Bahrain

A self-contained bilingual Arabic/English browser escape-room game.

## Play
Open `index.html` in a modern browser.

## Publish using GitHub Pages
1. Create a new public repository, e.g. `cloud-escape-bahrain`.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Select branch `main` and folder `/(root)`, then Save.
6. Open the public URL displayed in the Pages settings.

## Game
- Four rooms: S3 Vault, Network Gate, Cipher Chamber, Packet Storm.
- Correct answers reveal digits 4, 2, 7, 9.
- Final code: 4279.
- Use the language button to switch Arabic/English.
- Touchscreen-friendly; no external libraries needed.

Do not enter real passwords or personal information.
